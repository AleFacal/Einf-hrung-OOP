﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aufgabe04
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime from = dateTimePicker1.Value;
            DateTime to = DateTime.Now;
            TimeSpan TSpan = to - from;
            double days = TSpan.TotalDays;
            if (checkBox1.Checked)
            {
                textBox1.Text = (days / 365).ToString();
            }

            if (checkBox2.Checked)
            {
                textBox1.Text = (days / 365 * 12).ToString();
            }
            if (checkBox3.Checked)
            {
                textBox1.Text = (days / 365 * 12 * 4 * 7).ToString();
            }
            if (checkBox4.Checked)
            {
                textBox1.Text = (days / 365 * 12 * 4).ToString();
            }



        }
    }
}
